<?php
// Remove authentication requirement
// session_start();
// require_once 'auth.php';
// requireLogin();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant Management Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #e74c3c;
            --secondary-color: #2c3e50;
            --accent-color: #3498db;
            --success-color: #27ae60;
            --warning-color: #f39c12;
            --danger-color: #e74c3c;
            --light-color: #ecf0f1;
            --dark-color: #2c3e50;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* Header */
        .header {
            background: linear-gradient(135deg, var(--secondary-color) 0%, var(--primary-color) 100%);
            color: white;
            padding: 15px 30px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .header h3 {
            font-weight: 600;
            margin: 0;
            display: flex;
            align-items: center;
        }

        .header h3 i {
            margin-right: 10px;
            color: var(--warning-color);
        }

        /* Sidebar */
        .sidebar {
            background: white;
            min-height: calc(100vh - 70px);
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            position: relative;
        }

        .sidebar .nav-link {
            color: var(--dark-color);
            padding: 15px 20px;
            border-radius: 0;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            font-weight: 500;
        }

        .sidebar .nav-link:hover {
            background-color: rgba(231, 76, 60, 0.1);
            color: var(--primary-color);
            transform: translateX(5px);
        }

        .sidebar .nav-link.active {
            background-color: var(--primary-color);
            color: white;
            box-shadow: 0 4px 6px rgba(231, 76, 60, 0.2);
        }

        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        /* Main Content */
        .main-content {
            padding: 25px;
            background-color: #f8f9fa;
            min-height: calc(100vh - 70px);
        }

        /* Stats Cards */
        .stat-card {
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
            overflow: hidden;
            position: relative;
            margin-bottom: 25px;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 5px;
            height: 100%;
            background: var(--primary-color);
        }

        .stat-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
        }

        .stat-card .card-body {
            padding: 25px;
        }

        .stat-card i {
            font-size: 2.5rem;
            opacity: 0.8;
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
        }

        .stat-card h4 {
            font-weight: 700;
            margin-bottom: 5px;
        }

        .stat-card p {
            margin: 0;
            font-size: 0.9rem;
            opacity: 0.8;
        }

        /* Tables */
        .table-container {
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.08);
            padding: 25px;
            margin-top: 25px;
        }

        .table {
            border-collapse: separate;
            border-spacing: 0;
        }

        .table thead th {
            background-color: var(--light-color);
            border: none;
            font-weight: 600;
            color: var(--dark-color);
            padding: 15px;
        }

        .table tbody tr {
            transition: all 0.2s ease;
        }

        .table tbody tr:hover {
            background-color: rgba(231, 76, 60, 0.05);
            transform: scale(1.01);
        }

        .table td {
            padding: 15px;
            vertical-align: middle;
            border-top: 1px solid #eee;
        }

        /* Buttons */
        .btn-add {
            background: linear-gradient(135deg, var(--primary-color) 0%, #c0392b 100%);
            border: none;
            color: white;
            padding: 10px 20px;
            border-radius: 50px;
            font-weight: 500;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(231, 76, 60, 0.2);
        }

        .btn-add:hover {
            background: linear-gradient(135deg, #c0392b 0%, var(--primary-color) 100%);
            transform: translateY(-2px);
            box-shadow: 0 6px 8px rgba(231, 76, 60, 0.3);
        }

        /* Modals */
        .modal-header {
            background: linear-gradient(135deg, var(--secondary-color) 0%, var(--primary-color) 100%);
            color: white;
            border-radius: 15px 15px 0 0;
        }

        .modal-content {
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            border: none;
        }

        .modal-body {
            padding: 30px;
        }

        /* Forms */
        .form-control, .form-select {
            border-radius: 10px;
            border: 1px solid #ddd;
            padding: 12px 15px;
            transition: all 0.3s ease;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(231, 76, 60, 0.25);
        }

        .form-label {
            font-weight: 600;
            color: var(--dark-color);
            margin-bottom: 8px;
        }

        /* Status Badges */
        .status-badge {
            font-size: 0.8rem;
            padding: 6px 12px;
            border-radius: 50px;
            font-weight: 500;
        }

        .table-status-available {
            background-color: var(--success-color);
        }

        .table-status-occupied {
            background-color: var(--danger-color);
        }

        .table-status-reserved {
            background-color: var(--warning-color);
        }

        .order-status-pending {
            background-color: #6c757d;
        }

        .order-status-preparing {
            background-color: var(--accent-color);
        }

        .order-status-ready {
            background-color: var(--success-color);
        }

        .order-status-served {
            background-color: var(--accent-color);
        }

        .order-status-cancelled {
            background-color: var(--danger-color);
        }

        .order-status-paid {
            background-color: var(--success-color);
        }

        /* Page Title */
        .page-title {
            margin-bottom: 25px;
            color: var(--dark-color);
            font-weight: 600;
            position: relative;
            padding-bottom: 10px;
        }

        .page-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 50px;
            height: 3px;
            background: var(--primary-color);
        }

        /* Filter Section */
        .filter-section {
            background: white;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 25px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                position: fixed;
                left: -250px;
                width: 250px;
                height: 100vh;
                z-index: 999;
                transition: left 0.3s ease;
            }

            .sidebar.show {
                left: 0;
            }

            .main-content {
                margin-left: 0;
            }

            .mobile-menu-btn {
                display: block;
                position: fixed;
                top: 80px;
                left: 15px;
                z-index: 1001;
                background: var(--primary-color);
                color: white;
                border: none;
                border-radius: 50%;
                width: 50px;
                height: 50px;
                font-size: 1.2rem;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }
        }

        @media (min-width: 769px) {
            .mobile-menu-btn {
                display: none;
            }
        }

        /* Animations */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .fade-in {
            animation: fadeIn 0.5s ease forwards;
        }

        /* Chart Container */
        .chart-container {
            position: relative;
            height: 300px;
            margin-top: 20px;
        }

        /* Toast Container */
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1050;
        }

        /* Tab Navigation */
        .nav-tabs {
            border-bottom: none;
            margin-bottom: 20px;
        }

        .nav-tabs .nav-link {
            border: none;
            color: var(--dark-color);
            font-weight: 500;
            padding: 10px 20px;
            border-radius: 50px;
            margin-right: 10px;
            transition: all 0.3s ease;
        }

        .nav-tabs .nav-link.active {
            background: var(--primary-color);
            color: white;
        }

        .nav-tabs .nav-link:hover {
            background: rgba(231, 76, 60, 0.1);
        }

        /* Card Header */
        .card-header {
            background: linear-gradient(135deg, var(--light-color) 0%, white 100%);
            border-bottom: 1px solid #eee;
            font-weight: 600;
            color: var(--dark-color);
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h3><i class="fas fa-utensils"></i> Restaurant Management System</h3>
                </div>
                <div class="col-md-6 text-end">
                    <span class="text-light">Welcome to Restaurant Dashboard</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Mobile Menu Button -->
    <button class="mobile-menu-btn" id="mobile-menu-btn">
        <i class="fas fa-bars"></i>
    </button>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-3 col-lg-2 d-md-block sidebar" id="sidebar">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="#" data-page="dashboard">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-page="orders">
                                <i class="fas fa-receipt"></i> Orders
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-page="tables">
                                <i class="fas fa-table"></i> Tables
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-page="reservations">
                                <i class="fas fa-calendar-alt"></i> Reservations
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-page="menu">
                                <i class="fas fa-book-open"></i> Menu
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-page="inventory">
                                <i class="fas fa-boxes"></i> Inventory
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-page="customers">
                                <i class="fas fa-users"></i> Customers
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-page="reports">
                                <i class="fas fa-chart-bar"></i> Reports
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2" id="page-title">Dashboard</h1>
                </div>

                <!-- Dashboard Content -->
                <div id="dashboard-content" class="fade-in">
                    <!-- Stats Cards -->
                    <div class="row mb-4">
                        <div class="col-md-3 mb-3">
                            <div class="card stat-card text-white bg-primary">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <h4 class="card-title" id="today-orders">0</h4>
                                            <p class="card-text">Today's Orders</p>
                                        </div>
                                        <div>
                                            <i class="fas fa-receipt"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card stat-card text-white bg-success">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <h4 class="card-title" id="today-revenue">$0</h4>
                                            <p class="card-text">Today's Revenue</p>
                                        </div>
                                        <div>
                                            <i class="fas fa-dollar-sign"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card stat-card text-white bg-info">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <h4 class="card-title" id="active-tables">0</h4>
                                            <p class="card-text">Active Tables</p>
                                        </div>
                                        <div>
                                            <i class="fas fa-table"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card stat-card text-white bg-warning">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <h4 class="card-title" id="pending-reservations">0</h4>
                                            <p class="card-text">Pending Reservations</p>
                                        </div>
                                        <div>
                                            <i class="fas fa-calendar-alt"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Recent Orders Table -->
                    <div class="table-container">
                        <h5 class="page-title">Recent Orders</h5>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Order #</th>
                                        <th>Table</th>
                                        <th>Customer</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Time</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="recent-orders-tbody">
                                    <!-- Orders will be loaded here -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Orders Content -->
                <div id="orders-content" style="display: none;" class="fade-in">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="page-title">Orders Management</h5>
                        <button class="btn btn-add text-white" data-bs-toggle="modal" data-bs-target="#orderModal">
                            <i class="fas fa-plus"></i> New Order
                        </button>
                    </div>
                    
                    <div class="filter-section">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                                    <input type="text" class="form-control" id="order-search" placeholder="Search orders...">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <select class="form-select" id="order-status-filter">
                                    <option value="">All Status</option>
                                    <option value="pending">Pending</option>
                                    <option value="preparing">Preparing</option>
                                    <option value="ready">Ready</option>
                                    <option value="served">Served</option>
                                    <option value="cancelled">Cancelled</option>
                                    <option value="paid">Paid</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <input type="date" class="form-control" id="order-date-filter" value="<?php echo date('Y-m-d'); ?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="table-container">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Order #</th>
                                        <th>Table</th>
                                        <th>Customer</th>
                                        <th>Staff</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Time</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="orders-tbody">
                                    <!-- Orders will be loaded here -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Tables Content -->
                <div id="tables-content" style="display: none;" class="fade-in">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="page-title">Tables Management</h5>
                        <button class="btn btn-add text-white" data-bs-toggle="modal" data-bs-target="#tableModal">
                            <i class="fas fa-plus"></i> Add Table
                        </button>
                    </div>
                    
                    <div class="filter-section">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                                    <input type="text" class="form-control" id="table-search" placeholder="Search tables...">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <select class="form-select" id="table-status-filter">
                                    <option value="">All Status</option>
                                    <option value="available">Available</option>
                                    <option value="occupied">Occupied</option>
                                    <option value="reserved">Reserved</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <select class="form-select" id="table-location-filter">
                                    <option value="">All Locations</option>
                                    <option value="Indoor">Indoor</option>
                                    <option value="Outdoor">Outdoor</option>
                                    <option value="Private Room">Private Room</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="table-container">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Table #</th>
                                        <th>Capacity</th>
                                        <th>Status</th>
                                        <th>Location</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="tables-tbody">
                                    <!-- Tables will be loaded here -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Reservations Content -->
                <div id="reservations-content" style="display: none;" class="fade-in">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="page-title">Reservations Management</h5>
                        <button class="btn btn-add text-white" data-bs-toggle="modal" data-bs-target="#reservationModal">
                            <i class="fas fa-plus"></i> New Reservation
                        </button>
                    </div>
                    
                    <div class="filter-section">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                                    <input type="text" class="form-control" id="reservation-search" placeholder="Search reservations...">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <select class="form-select" id="reservation-status-filter">
                                    <option value="">All Status</option>
                                    <option value="pending">Pending</option>
                                    <option value="confirmed">Confirmed</option>
                                    <option value="cancelled">Cancelled</option>
                                    <option value="completed">Completed</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <input type="date" class="form-control" id="reservation-date-filter" value="<?php echo date('Y-m-d'); ?>">
                            </div>
                            <div class="col-md-2">
                                <button class="btn btn-outline-primary w-100" id="refresh-reservations">
                                    <i class="fas fa-sync-alt"></i> Refresh
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="table-container">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Customer</th>
                                        <th>Table</th>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Party Size</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="reservations-tbody">
                                    <!-- Reservations will be loaded here -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Menu Content -->
                <div id="menu-content" style="display: none;" class="fade-in">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="page-title">Menu Management</h5>
                        <button class="btn btn-add text-white" data-bs-toggle="modal" data-bs-target="#menuModal">
                            <i class="fas fa-plus"></i> Add Item
                        </button>
                    </div>
                    
                    <div class="filter-section">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                                    <input type="text" class="form-control" id="menu-search" placeholder="Search menu items...">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <select class="form-select" id="menu-category-filter">
                                    <option value="">All Categories</option>
                                    <!-- Categories will be loaded here -->
                                </select>
                            </div>
                            <div class="col-md-3">
                                <select class="form-select" id="menu-availability-filter">
                                    <option value="">All Items</option>
                                    <option value="1">Available</option>
                                    <option value="0">Unavailable</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="table-container">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Category</th>
                                        <th>Price</th>
                                        <th>Availability</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="menu-tbody">
                                    <!-- Menu items will be loaded here -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Inventory Content -->
                <div id="inventory-content" style="display: none;" class="fade-in">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="page-title">Inventory Management</h5>
                        <button class="btn btn-add text-white" data-bs-toggle="modal" data-bs-target="#inventoryModal">
                            <i class="fas fa-plus"></i> Add Item
                        </button>
                    </div>
                    
                    <div class="filter-section">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                                    <input type="text" class="form-control" id="inventory-search" placeholder="Search inventory items...">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <select class="form-select" id="inventory-stock-filter">
                                    <option value="">All Items</option>
                                    <option value="low">Low Stock</option>
                                    <option value="ok">In Stock</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="table-container">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Description</th>
                                        <th>Quantity</th>
                                        <th>Unit</th>
                                        <th>Min. Stock</th>
                                        <th>Unit Cost</th>
                                        <th>Total Value</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="inventory-tbody">
                                    <!-- Inventory items will be loaded here -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Customers Content -->
                <div id="customers-content" style="display: none;" class="fade-in">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="page-title">Customers Management</h5>
                        <button class="btn btn-add text-white" data-bs-toggle="modal" data-bs-target="#customerModal">
                            <i class="fas fa-plus"></i> Add Customer
                        </button>
                    </div>
                    
                    <div class="filter-section">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                                    <input type="text" class="form-control" id="customer-search" placeholder="Search customers...">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="table-container">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="customers-tbody">
                                    <!-- Customers will be loaded here -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Reports Content -->
                <div id="reports-content" style="display: none;" class="fade-in">
                    <h5 class="page-title">Reports</h5>
                    
                    <div class="table-container">
                        <div class="card">
                            <div class="card-header">
                                <ul class="nav nav-tabs card-header-tabs" id="reportTabs" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link active" id="sales-tab" data-bs-toggle="tab" data-bs-target="#sales" type="button" role="tab">Sales Report</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="inventory-tab" data-bs-toggle="tab" data-bs-target="#inventory" type="button" role="tab">Inventory Report</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="reservations-tab" data-bs-toggle="tab" data-bs-target="#reservations" type="button" role="tab">Reservations Report</button>
                                    </li>
                                </ul>
                            </div>
                            <div class="card-body">
                                <div class="tab-content" id="reportTabContent">
                                    <div class="tab-pane fade show active" id="sales" role="tabpanel">
                                        <div class="row mb-3">
                                            <div class="col-md-4">
                                                <label for="sales-start-date" class="form-label">Start Date</label>
                                                <input type="date" class="form-control" id="sales-start-date" value="<?php echo date('Y-m-01'); ?>">
                                            </div>
                                            <div class="col-md-4">
                                                <label for="sales-end-date" class="form-label">End Date</label>
                                                <input type="date" class="form-control" id="sales-end-date" value="<?php echo date('Y-m-t'); ?>">
                                            </div>
                                            <div class="col-md-4 d-flex align-items-end">
                                                <button class="btn btn-primary w-100" id="generate-sales-report">
                                                    <i class="fas fa-chart-bar"></i> Generate Report
                                                </button>
                                            </div>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-8">
                                                <div class="chart-container">
                                                    <canvas id="sales-chart"></canvas>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <h6>Top Selling Items</h6>
                                                <div id="top-items-list">
                                                    <!-- Top items will be loaded here -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="inventory" role="tabpanel">
                                        <div class="row mb-3">
                                            <div class="col-md-12">
                                                <button class="btn btn-primary" id="generate-inventory-report">
                                                    <i class="fas fa-boxes"></i> Generate Report
                                                </button>
                                            </div>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="card">
                                                    <div class="card-header">
                                                        <h6>Low Stock Items</h6>
                                                    </div>
                                                    <div class="card-body">
                                                        <div id="low-stock-items">
                                                            <!-- Low stock items will be loaded here -->
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="card">
                                                    <div class="card-header">
                                                        <h6>Inventory Value</h6>
                                                    </div>
                                                    <div class="card-body">
                                                        <h3 id="inventory-value">$0</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="reservations" role="tabpanel">
                                        <div class="row mb-3">
                                            <div class="col-md-4">
                                                <label for="reservations-start-date" class="form-label">Start Date</label>
                                                <input type="date" class="form-control" id="reservations-start-date" value="<?php echo date('Y-m-01'); ?>">
                                            </div>
                                            <div class="col-md-4">
                                                <label for="reservations-end-date" class="form-label">End Date</label>
                                                <input type="date" class="form-control" id="reservations-end-date" value="<?php echo date('Y-m-t'); ?>">
                                            </div>
                                            <div class="col-md-4 d-flex align-items-end">
                                                <button class="btn btn-primary w-100" id="generate-reservations-report">
                                                    <i class="fas fa-calendar-alt"></i> Generate Report
                                                </button>
                                            </div>
                                        </div>
                                        
                                        <div class="chart-container">
                                            <canvas id="reservations-chart"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Toast Container -->
    <div class="toast-container"></div>

    <!-- Order Modal -->
    <div class="modal fade" id="orderModal" tabindex="-1" aria-labelledby="orderModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="orderModalLabel">New Order</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="order-form">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="order-table" class="form-label">Table</label>
                                <select class="form-select" id="order-table" required>
                                    <option value="">Select Table</option>
                                    <!-- Tables will be loaded here -->
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="order-customer" class="form-label">Customer</label>
                                <select class="form-select" id="order-customer">
                                    <option value="">Select Customer (Optional)</option>
                                    <!-- Customers will be loaded here -->
                                </select>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Order Items</label>
                            <div id="order-items">
                                <div class="row mb-2 order-item-row">
                                    <div class="col-md-5">
                                        <select class="form-select menu-item-select" required>
                                            <option value="">Select Item</option>
                                            <!-- Menu items will be loaded here -->
                                        </select>
                                    </div>
                                    <div class="col-md-2">
                                        <input type="number" class="form-control item-quantity" min="1" value="1" required>
                                    </div>
                                    <div class="col-md-3">
                                        <input type="text" class="form-control item-price" readonly>
                                    </div>
                                    <div class="col-md-2">
                                        <button type="button" class="btn btn-danger btn-sm remove-item">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <button type="button" class="btn btn-outline-secondary btn-sm mt-2" id="add-order-item">
                                <i class="fas fa-plus"></i> Add Item
                            </button>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <label for="order-total" class="form-label">Total Amount</label>
                                <input type="text" class="form-control" id="order-total" readonly>
                            </div>
                            <div class="col-md-6">
                                <label for="order-notes" class="form-label">Notes</label>
                                <textarea class="form-control" id="order-notes" rows="1"></textarea>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" id="save-order">Save Order</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Table Modal -->
    <div class="modal fade" id="tableModal" tabindex="-1" aria-labelledby="tableModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="tableModalLabel">Add Table</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="table-form">
                        <div class="mb-3">
                            <label for="table-number" class="form-label">Table Number</label>
                            <input type="text" class="form-control" id="table-number" required>
                        </div>
                        <div class="mb-3">
                            <label for="table-capacity" class="form-label">Capacity</label>
                            <input type="number" class="form-control" id="table-capacity" min="1" required>
                        </div>
                        <div class="mb-3">
                            <label for="table-location" class="form-label">Location</label>
                            <select class="form-select" id="table-location">
                                <option value="Indoor">Indoor</option>
                                <option value="Outdoor">Outdoor</option>
                                <option value="Private Room">Private Room</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" id="save-table">Save Table</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Reservation Modal -->
    <div class="modal fade" id="reservationModal" tabindex="-1" aria-labelledby="reservationModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="reservationModalLabel">New Reservation</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="reservation-form">
                        <div class="mb-3">
                            <label for="reservation-customer-name" class="form-label">Customer Name</label>
                            <input type="text" class="form-control" id="reservation-customer-name" required>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="reservation-customer-email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="reservation-customer-email">
                            </div>
                            <div class="col-md-6">
                                <label for="reservation-customer-phone" class="form-label">Phone</label>
                                <input type="tel" class="form-control" id="reservation-customer-phone">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="reservation-date" class="form-label">Date</label>
                                <input type="date" class="form-control" id="reservation-date" required>
                            </div>
                            <div class="col-md-6">
                                <label for="reservation-time" class="form-label">Time</label>
                                <input type="time" class="form-control" id="reservation-time" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="reservation-table" class="form-label">Table</label>
                                <select class="form-select" id="reservation-table" required>
                                    <option value="">Select Table</option>
                                    <!-- Tables will be loaded here -->
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="reservation-party-size" class="form-label">Party Size</label>
                                <input type="number" class="form-control" id="reservation-party-size" min="1" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="reservation-special-requests" class="form-label">Special Requests</label>
                            <textarea class="form-control" id="reservation-special-requests" rows="2"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" id="save-reservation">Save Reservation</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Menu Modal -->
    <div class="modal fade" id="menuModal" tabindex="-1" aria-labelledby="menuModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="menuModalLabel">Add Menu Item</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="menu-form">
                        <div class="mb-3">
                            <label for="menu-name" class="form-label">Name</label>
                            <input type="text" class="form-control" id="menu-name" required>
                        </div>
                        <div class="mb-3">
                            <label for="menu-description" class="form-label">Description</label>
                            <textarea class="form-control" id="menu-description" rows="2"></textarea>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="menu-price" class="form-label">Price</label>
                                <input type="number" class="form-control" id="menu-price" min="0" step="0.01" required>
                            </div>
                            <div class="col-md-6">
                                <label for="menu-category" class="form-label">Category</label>
                                <select class="form-select" id="menu-category" required>
                                    <option value="">Select Category</option>
                                    <!-- Categories will be loaded here -->
                                </select>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="menu-image" class="form-label">Image URL</label>
                            <input type="text" class="form-control" id="menu-image">
                        </div>
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="menu-available" checked>
                                <label class="form-check-label" for="menu-available">
                                    Available
                                </label>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" id="save-menu">Save Item</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Inventory Modal -->
    <div class="modal fade" id="inventoryModal" tabindex="-1" aria-labelledby="inventoryModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="inventoryModalLabel">Add Inventory Item</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="inventory-form">
                        <div class="mb-3">
                            <label for="inventory-name" class="form-label">Name</label>
                            <input type="text" class="form-control" id="inventory-name" required>
                        </div>
                        <div class="mb-3">
                            <label for="inventory-description" class="form-label">Description</label>
                            <textarea class="form-control" id="inventory-description" rows="2"></textarea>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-4">
                                <label for="inventory-quantity" class="form-label">Quantity</label>
                                <input type="number" class="form-control" id="inventory-quantity" min="0" step="0.01" required>
                            </div>
                            <div class="col-md-4">
                                <label for="inventory-unit" class="form-label">Unit</label>
                                <input type="text" class="form-control" id="inventory-unit" required>
                            </div>
                            <div class="col-md-4">
                                <label for="inventory-minimum-stock" class="form-label">Min. Stock</label>
                                <input type="number" class="form-control" id="inventory-minimum-stock" min="0" step="0.01" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="inventory-unit-cost" class="form-label">Unit Cost</label>
                            <input type="number" class="form-control" id="inventory-unit-cost" min="0" step="0.01" required>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" id="save-inventory">Save Item</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Customer Modal -->
    <div class="modal fade" id="customerModal" tabindex="-1" aria-labelledby="customerModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="customerModalLabel">Add Customer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="customer-form">
                        <div class="mb-3">
                            <label for="customer-name" class="form-label">Name</label>
                            <input type="text" class="form-control" id="customer-name" required>
                        </div>
                        <div class="mb-3">
                            <label for="customer-email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="customer-email">
                        </div>
                        <div class="mb-3">
                            <label for="customer-phone" class="form-label">Phone</label>
                            <input type="tel" class="form-control" id="customer-phone">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" id="save-customer">Save Customer</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Update Order Status Modal -->
    <div class="modal fade" id="updateOrderStatusModal" tabindex="-1" aria-labelledby="updateOrderStatusModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="updateOrderStatusModalLabel">Update Order Status</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="update-order-status-form">
                        <input type="hidden" id="update-order-id">
                        <div class="mb-3">
                            <label for="update-order-status" class="form-label">Status</label>
                            <select class="form-select" id="update-order-status" required>
                                <option value="pending">Pending</option>
                                <option value="preparing">Preparing</option>
                                <option value="ready">Ready</option>
                                <option value="served">Served</option>
                                <option value="cancelled">Cancelled</option>
                                <option value="paid">Paid</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" id="update-order-status-btn">Update Status</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Update Table Status Modal -->
    <div class="modal fade" id="updateTableStatusModal" tabindex="-1" aria-labelledby="updateTableStatusModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="updateTableStatusModalLabel">Update Table Status</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="update-table-status-form">
                        <input type="hidden" id="update-table-id">
                        <div class="mb-3">
                            <label for="update-table-status" class="form-label">Status</label>
                            <select class="form-select" id="update-table-status" required>
                                <option value="available">Available</option>
                                <option value="occupied">Occupied</option>
                                <option value="reserved">Reserved</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" id="update-table-status-btn">Update Status</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Update Reservation Status Modal -->
    <div class="modal fade" id="updateReservationStatusModal" tabindex="-1" aria-labelledby="updateReservationStatusModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="updateReservationStatusModalLabel">Update Reservation Status</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="update-reservation-status-form">
                        <input type="hidden" id="update-reservation-id">
                        <div class="mb-3">
                            <label for="update-reservation-status" class="form-label">Status</label>
                            <select class="form-select" id="update-reservation-status" required>
                                <option value="pending">Pending</option>
                                <option value="confirmed">Confirmed</option>
                                <option value="cancelled">Cancelled</option>
                                <option value="completed">Completed</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" id="update-reservation-status-btn">Update Status</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Inventory Transaction Modal -->
    <div class="modal fade" id="inventoryTransactionModal" tabindex="-1" aria-labelledby="inventoryTransactionModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="inventoryTransactionModalLabel">Inventory Transaction</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="inventory-transaction-form">
                        <input type="hidden" id="transaction-inventory-id">
                        <div class="mb-3">
                            <label for="transaction-type" class="form-label">Transaction Type</label>
                            <select class="form-select" id="transaction-type" required>
                                <option value="in">Stock In</option>
                                <option value="out">Stock Out</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="transaction-quantity" class="form-label">Quantity</label>
                            <input type="number" class="form-control" id="transaction-quantity" min="0.01" step="0.01" required>
                        </div>
                        <div class="mb-3">
                            <label for="transaction-reference" class="form-label">Reference</label>
                            <input type="text" class="form-control" id="transaction-reference">
                        </div>
                        <div class="mb-3">
                            <label for="transaction-notes" class="form-label">Notes</label>
                            <textarea class="form-control" id="transaction-notes" rows="2"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" id="save-transaction">Save Transaction</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Global variables
        let currentPage = 'dashboard';
        let menuItems = [];
        let tables = [];
        let customers = [];
        let categories = [];
        
        // API base URL
        const API_BASE_URL = 'api/index.php';
        
        // Mobile menu toggle
        document.getElementById('mobile-menu-btn').addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('show');
        });
        
        // Show toast notification
        function showToast(message, type = 'success') {
            const toastContainer = document.querySelector('.toast-container');
            const toastId = 'toast-' + Date.now();
            
            const toastHtml = `
                <div id="${toastId}" class="toast align-items-center text-white bg-${type === 'success' ? 'success' : 'danger'} border-0" role="alert" aria-live="assertive" aria-atomic="true">
                    <div class="d-flex">
                        <div class="toast-body">
                            ${message}
                        </div>
                        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
                    </div>
                </div>
            `;
            
            toastContainer.insertAdjacentHTML('beforeend', toastHtml);
            
            const toastElement = document.getElementById(toastId);
            const toast = new bootstrap.Toast(toastElement);
            toast.show();
            
            // Remove toast element after it's hidden
            toastElement.addEventListener('hidden.bs.toast', () => {
                toastElement.remove();
            });
        }
        
        // Fetch data from API
        async function fetchData(endpoint) {
            try {
                const response = await fetch(`${API_BASE_URL}/${endpoint}`);
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return await response.json();
            } catch (error) {
                console.error('Error fetching data:', error);
                showToast('Error fetching data', 'error');
                return null;
            }
        }
        
        // Send data to API
        async function sendData(endpoint, method, data = null) {
            try {
                const options = {
                    method: method,
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };
                
                if (data) {
                    options.body = JSON.stringify(data);
                }
                
                const response = await fetch(`${API_BASE_URL}/${endpoint}`, options);
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return await response.json();
            } catch (error) {
                console.error('Error sending data:', error);
                showToast('Error sending data', 'error');
                return null;
            }
        }
        
        // Format currency
        function formatCurrency(amount) {
            return new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: 'USD'
            }).format(amount);
        }
        
        // Format date and time
        function formatDateTime(dateTime) {
            const date = new Date(dateTime);
            return date.toLocaleString();
        }
        
        // Format date
        function formatDate(date) {
            const d = new Date(date);
            return d.toLocaleDateString();
        }
        
        // Format time
        function formatTime(time) {
            const t = new Date(`2000-01-01T${time}`);
            return t.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        }
        
        // Load dashboard data
        async function loadDashboardData() {
            // Load today's orders
            const today = new Date().toISOString().split('T')[0];
            const orders = await fetchData(`orders?date=${today}`);
            
            if (orders) {
                document.getElementById('today-orders').textContent = orders.length;
                
                // Calculate today's revenue
                const revenue = orders
                    .filter(order => order.status === 'paid')
                    .reduce((sum, order) => sum + parseFloat(order.total_amount), 0);
                document.getElementById('today-revenue').textContent = formatCurrency(revenue);
                
                // Load recent orders (max 5)
                const recentOrders = orders.slice(0, 5);
                const recentOrdersTbody = document.getElementById('recent-orders-tbody');
                recentOrdersTbody.innerHTML = '';
                
                recentOrders.forEach(order => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${order.order_number}</td>
                        <td>${order.table_number || 'N/A'}</td>
                        <td>${order.customer_name || 'Walk-in'}</td>
                        <td>${formatCurrency(order.total_amount)}</td>
                        <td><span class="badge status-badge order-status-${order.status}">${order.status}</span></td>
                        <td>${formatDateTime(order.order_date)}</td>
                        <td class="table-actions">
                            <button class="btn btn-sm btn-outline-primary view-order" data-id="${order.id}">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="btn btn-sm btn-outline-secondary update-order-status" data-id="${order.id}" data-status="${order.status}">
                                <i class="fas fa-edit"></i>
                            </button>
                        </td>
                    `;
                    recentOrdersTbody.appendChild(row);
                });
                
                // Add event listeners to order buttons
                document.querySelectorAll('.view-order').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const orderId = this.getAttribute('data-id');
                        viewOrder(orderId);
                    });
                });
                
                document.querySelectorAll('.update-order-status').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const orderId = this.getAttribute('data-id');
                        const currentStatus = this.getAttribute('data-status');
                        updateOrderStatus(orderId, currentStatus);
                    });
                });
            }
            
            // Load active tables
            const tablesData = await fetchData('tables');
            if (tablesData) {
                tables = tablesData;
                const activeTables = tablesData.filter(table => table.status === 'occupied').length;
                document.getElementById('active-tables').textContent = activeTables;
            }
            
            // Load pending reservations
            const reservations = await fetchData(`reservations?date=${today}`);
            if (reservations) {
                const pendingReservations = reservations.filter(reservation => reservation.status === 'pending').length;
                document.getElementById('pending-reservations').textContent = pendingReservations;
            }
        }
        
        // Load orders data
        async function loadOrdersData() {
            const date = document.getElementById('order-date-filter').value;
            const status = document.getElementById('order-status-filter').value;
            
            let endpoint = `orders?date=${date}`;
            if (status) {
                endpoint += `&status=${status}`;
            }
            
            const orders = await fetchData(endpoint);
            
            if (orders) {
                const ordersTbody = document.getElementById('orders-tbody');
                ordersTbody.innerHTML = '';
                
                orders.forEach(order => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${order.order_number}</td>
                        <td>${order.table_number || 'N/A'}</td>
                        <td>${order.customer_name || 'Walk-in'}</td>
                        <td>${order.staff_name || 'N/A'}</td>
                        <td>${formatCurrency(order.total_amount)}</td>
                        <td><span class="badge status-badge order-status-${order.status}">${order.status}</span></td>
                        <td>${formatDateTime(order.order_date)}</td>
                        <td class="table-actions">
                            <button class="btn btn-sm btn-outline-primary view-order" data-id="${order.id}">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="btn btn-sm btn-outline-secondary update-order-status" data-id="${order.id}" data-status="${order.status}">
                                <i class="fas fa-edit"></i>
                            </button>
                        </td>
                    `;
                    ordersTbody.appendChild(row);
                });
                
                // Add event listeners to order buttons
                document.querySelectorAll('.view-order').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const orderId = this.getAttribute('data-id');
                        viewOrder(orderId);
                    });
                });
                
                document.querySelectorAll('.update-order-status').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const orderId = this.getAttribute('data-id');
                        const currentStatus = this.getAttribute('data-status');
                        updateOrderStatus(orderId, currentStatus);
                    });
                });
            }
        }
        
        // Load tables data
        async function loadTablesData() {
            const tablesData = await fetchData('tables');
            
            if (tablesData) {
                tables = tablesData;
                const tablesTbody = document.getElementById('tables-tbody');
                tablesTbody.innerHTML = '';
                
                tablesData.forEach(table => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${table.table_number}</td>
                        <td>${table.capacity}</td>
                        <td><span class="badge status-badge table-status-${table.status}">${table.status}</span></td>
                        <td>${table.location || 'N/A'}</td>
                        <td class="table-actions">
                            <button class="btn btn-sm btn-outline-secondary update-table-status" data-id="${table.id}" data-status="${table.status}">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-outline-danger delete-table" data-id="${table.id}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    `;
                    tablesTbody.appendChild(row);
                });
                
                // Add event listeners to table buttons
                document.querySelectorAll('.update-table-status').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const tableId = this.getAttribute('data-id');
                        const currentStatus = this.getAttribute('data-status');
                        updateTableStatus(tableId, currentStatus);
                    });
                });
                
                document.querySelectorAll('.delete-table').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const tableId = this.getAttribute('data-id');
                        if (confirm('Are you sure you want to delete this table?')) {
                            deleteTable(tableId);
                        }
                    });
                });
            }
        }
        
        // Load reservations data
        async function loadReservationsData() {
            const date = document.getElementById('reservation-date-filter').value;
            const status = document.getElementById('reservation-status-filter').value;
            
            let endpoint = `reservations?date=${date}`;
            if (status) {
                endpoint += `&status=${status}`;
            }
            
            const reservations = await fetchData(endpoint);
            
            if (reservations) {
                const reservationsTbody = document.getElementById('reservations-tbody');
                reservationsTbody.innerHTML = '';
                
                reservations.forEach(reservation => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${reservation.customer_name}</td>
                        <td>${reservation.table_number}</td>
                        <td>${formatDate(reservation.reservation_date)}</td>
                        <td>${formatTime(reservation.reservation_time)}</td>
                        <td>${reservation.party_size}</td>
                        <td><span class="badge status-badge reservation-status-${reservation.status}">${reservation.status}</span></td>
                        <td class="table-actions">
                            <button class="btn btn-sm btn-outline-secondary update-reservation-status" data-id="${reservation.id}" data-status="${reservation.status}">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-outline-danger delete-reservation" data-id="${reservation.id}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    `;
                    reservationsTbody.appendChild(row);
                });
                
                // Add event listeners to reservation buttons
                document.querySelectorAll('.update-reservation-status').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const reservationId = this.getAttribute('data-id');
                        const currentStatus = this.getAttribute('data-status');
                        updateReservationStatus(reservationId, currentStatus);
                    });
                });
                
                document.querySelectorAll('.delete-reservation').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const reservationId = this.getAttribute('data-id');
                        if (confirm('Are you sure you want to delete this reservation?')) {
                            deleteReservation(reservationId);
                        }
                    });
                });
            }
        }
        
        // Load menu data
        async function loadMenuData() {
            const menuItemsData = await fetchData('menu');
            const categoriesData = await fetchData('categories');
            
            if (menuItemsData && categoriesData) {
                menuItems = menuItemsData;
                categories = categoriesData;
                
                // Populate category filter
                const categoryFilter = document.getElementById('menu-category-filter');
                categoryFilter.innerHTML = '<option value="">All Categories</option>';
                
                categoriesData.forEach(category => {
                    const option = document.createElement('option');
                    option.value = category.id;
                    option.textContent = category.name;
                    categoryFilter.appendChild(option);
                });
                
                // Populate category dropdown in menu modal
                const menuCategory = document.getElementById('menu-category');
                menuCategory.innerHTML = '<option value="">Select Category</option>';
                
                categoriesData.forEach(category => {
                    const option = document.createElement('option');
                    option.value = category.id;
                    option.textContent = category.name;
                    menuCategory.appendChild(option);
                });
                
                // Populate menu items in order modal
                const menuItemSelects = document.querySelectorAll('.menu-item-select');
                menuItemSelects.forEach(select => {
                    select.innerHTML = '<option value="">Select Item</option>';
                    
                    menuItemsData.forEach(item => {
                        if (item.is_available) {
                            const option = document.createElement('option');
                            option.value = item.id;
                            option.textContent = `${item.name} - ${formatCurrency(item.price)}`;
                            option.setAttribute('data-price', item.price);
                            select.appendChild(option);
                        }
                    });
                });
                
                // Display menu items
                displayMenuItems(menuItemsData);
            }
        }
        
        // Display menu items
        function displayMenuItems(items) {
            const menuTbody = document.getElementById('menu-tbody');
            menuTbody.innerHTML = '';
            
            items.forEach(item => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${item.name}</td>
                    <td>${item.category_name || 'N/A'}</td>
                    <td>${formatCurrency(item.price)}</td>
                    <td>
                        <span class="badge ${item.is_available ? 'bg-success' : 'bg-danger'}">
                            ${item.is_available ? 'Available' : 'Unavailable'}
                        </span>
                    </td>
                    <td class="table-actions">
                        <button class="btn btn-sm btn-outline-primary edit-menu" data-id="${item.id}">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-danger delete-menu" data-id="${item.id}">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                `;
                menuTbody.appendChild(row);
            });
            
            // Add event listeners to menu buttons
            document.querySelectorAll('.edit-menu').forEach(btn => {
                btn.addEventListener('click', function() {
                    const itemId = this.getAttribute('data-id');
                    editMenuItem(itemId);
                });
            });
            
            document.querySelectorAll('.delete-menu').forEach(btn => {
                btn.addEventListener('click', function() {
                    const itemId = this.getAttribute('data-id');
                    if (confirm('Are you sure you want to delete this menu item?')) {
                        deleteMenuItem(itemId);
                    }
                });
            });
        }
        
        // Load inventory data
        async function loadInventoryData() {
            const inventoryItems = await fetchData('inventory');
            
            if (inventoryItems) {
                const inventoryTbody = document.getElementById('inventory-tbody');
                inventoryTbody.innerHTML = '';
                
                inventoryItems.forEach(item => {
                    const isLowStock = parseFloat(item.quantity) <= parseFloat(item.minimum_stock);
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${item.name}</td>
                        <td>${item.description || 'N/A'}</td>
                        <td class="${isLowStock ? 'inventory-low' : 'inventory-ok'}">${item.quantity} ${item.unit}</td>
                        <td>${item.unit}</td>
                        <td>${item.minimum_stock} ${item.unit}</td>
                        <td>${formatCurrency(item.unit_cost)}</td>
                        <td>${formatCurrency(item.quantity * item.unit_cost)}</td>
                        <td class="table-actions">
                            <button class="btn btn-sm btn-outline-primary add-transaction" data-id="${item.id}" data-name="${item.name}" data-quantity="${item.quantity}" data-unit="${item.unit}">
                                <i class="fas fa-exchange-alt"></i>
                            </button>
                            <button class="btn btn-sm btn-outline-secondary edit-inventory" data-id="${item.id}">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-outline-danger delete-inventory" data-id="${item.id}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    `;
                    inventoryTbody.appendChild(row);
                });
                
                // Add event listeners to inventory buttons
                document.querySelectorAll('.add-transaction').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const itemId = this.getAttribute('data-id');
                        const itemName = this.getAttribute('data-name');
                        const itemQuantity = this.getAttribute('data-quantity');
                        const itemUnit = this.getAttribute('data-unit');
                        addInventoryTransaction(itemId, itemName, itemQuantity, itemUnit);
                    });
                });
                
                document.querySelectorAll('.edit-inventory').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const itemId = this.getAttribute('data-id');
                        editInventoryItem(itemId);
                    });
                });
                
                document.querySelectorAll('.delete-inventory').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const itemId = this.getAttribute('data-id');
                        if (confirm('Are you sure you want to delete this inventory item?')) {
                            deleteInventoryItem(itemId);
                        }
                    });
                });
            }
        }
        
        // Load customers data
        async function loadCustomersData() {
            const customersData = await fetchData('customers');
            
            if (customersData) {
                customers = customersData;
                const customersTbody = document.getElementById('customers-tbody');
                customersTbody.innerHTML = '';
                
                customersData.forEach(customer => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${customer.name}</td>
                        <td>${customer.email || 'N/A'}</td>
                        <td>${customer.phone || 'N/A'}</td>
                        <td class="table-actions">
                            <button class="btn btn-sm btn-outline-primary edit-customer" data-id="${customer.id}">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-outline-danger delete-customer" data-id="${customer.id}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    `;
                    customersTbody.appendChild(row);
                });
                
                // Add event listeners to customer buttons
                document.querySelectorAll('.edit-customer').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const customerId = this.getAttribute('data-id');
                        editCustomer(customerId);
                    });
                });
                
                document.querySelectorAll('.delete-customer').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const customerId = this.getAttribute('data-id');
                        if (confirm('Are you sure you want to delete this customer?')) {
                            deleteCustomer(customerId);
                        }
                    });
                });
                
                // Update customer dropdown in order modal
                const orderCustomer = document.getElementById('order-customer');
                orderCustomer.innerHTML = '<option value="">Select Customer (Optional)</option>';
                
                customersData.forEach(customer => {
                    const option = document.createElement('option');
                    option.value = customer.id;
                    option.textContent = customer.name;
                    orderCustomer.appendChild(option);
                });
            }
        }
        
        // Load reports data
        async function loadReportsData(type) {
            let startDate, endDate;
            
            if (type === 'sales') {
                startDate = document.getElementById('sales-start-date').value;
                endDate = document.getElementById('sales-end-date').value;
            } else if (type === 'reservations') {
                startDate = document.getElementById('reservations-start-date').value;
                endDate = document.getElementById('reservations-end-date').value;
            }
            
            const reportData = await fetchData(`reports?type=${type}&start_date=${startDate}&end_date=${endDate}`);
            
            if (reportData) {
                if (type === 'sales') {
                    displaySalesReport(reportData);
                } else if (type === 'inventory') {
                    displayInventoryReport(reportData);
                } else if (type === 'reservations') {
                    displayReservationsReport(reportData);
                }
            }
        }
        
        // Display sales report
        function displaySalesReport(data) {
            // Create sales chart
            const ctx = document.getElementById('sales-chart').getContext('2d');
            
            // Destroy existing chart if it exists
            if (window.salesChart) {
                window.salesChart.destroy();
            }
            
            window.salesChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.sales_data.map(item => item.date),
                    datasets: [{
                        label: 'Daily Sales',
                        data: data.sales_data.map(item => parseFloat(item.total_sales)),
                        backgroundColor: 'rgba(231, 76, 60, 0.2)',
                        borderColor: 'rgba(231, 76, 60, 1)',
                        borderWidth: 2,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return formatCurrency(value);
                                }
                            }
                        }
                    },
                    plugins: {
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return 'Sales: ' + formatCurrency(context.raw);
                                }
                            }
                        }
                    }
                }
            });
            
            // Display top selling items
            const topItemsList = document.getElementById('top-items-list');
            topItemsList.innerHTML = '';
            
            data.top_items.forEach(item => {
                const itemDiv = document.createElement('div');
                itemDiv.className = 'd-flex justify-content-between align-items-center mb-2';
                itemDiv.innerHTML = `
                    <span>${item.name}</span>
                    <span>${item.total_quantity} units (${formatCurrency(item.total_revenue)})</span>
                `;
                topItemsList.appendChild(itemDiv);
            });
        }
        
        // Display inventory report
        function displayInventoryReport(data) {
            // Display low stock items
            const lowStockItems = document.getElementById('low-stock-items');
            lowStockItems.innerHTML = '';
            
            if (data.low_stock_items.length === 0) {
                lowStockItems.innerHTML = '<p class="text-muted">No items with low stock</p>';
            } else {
                data.low_stock_items.forEach(item => {
                    const itemDiv = document.createElement('div');
                    itemDiv.className = 'd-flex justify-content-between align-items-center mb-2';
                    itemDiv.innerHTML = `
                        <span>${item.name}</span>
                        <span class="inventory-low">${item.quantity} ${item.unit} (Min: ${item.minimum_stock} ${item.unit})</span>
                    `;
                    lowStockItems.appendChild(itemDiv);
                });
            }
            
            // Display inventory value
            document.getElementById('inventory-value').textContent = formatCurrency(data.total_value);
        }
        
        // Display reservations report
        function displayReservationsReport(data) {
            // Create reservations chart
            const ctx = document.getElementById('reservations-chart').getContext('2d');
            
            // Destroy existing chart if it exists
            if (window.reservationsChart) {
                window.reservationsChart.destroy();
            }
            
            window.reservationsChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: data.reservation_data.map(item => item.date),
                    datasets: [
                        {
                            label: 'Reservations',
                            data: data.reservation_data.map(item => parseInt(item.reservation_count)),
                            backgroundColor: 'rgba(52, 152, 219, 0.5)',
                            borderColor: 'rgba(52, 152, 219, 1)',
                            borderWidth: 1
                        },
                        {
                            label: 'Total Guests',
                            data: data.reservation_data.map(item => parseInt(item.total_guests)),
                            backgroundColor: 'rgba(39, 174, 96, 0.5)',
                            borderColor: 'rgba(39, 174, 96, 1)',
                            borderWidth: 1
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }
        
        // View order details
        async function viewOrder(orderId) {
            const order = await fetchData(`orders/${orderId}`);
            
            if (order) {
                let itemsHtml = '';
                order.items.forEach(item => {
                    itemsHtml += `
                        <tr>
                            <td>${item.item_name}</td>
                            <td>${item.quantity}</td>
                            <td>${formatCurrency(item.price)}</td>
                            <td>${formatCurrency(item.quantity * item.price)}</td>
                            <td>${item.notes || 'N/A'}</td>
                        </tr>
                    `;
                });
                
                const orderDetailsHtml = `
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Order Number:</strong> ${order.order_number}
                        </div>
                        <div class="col-md-6">
                            <strong>Status:</strong> <span class="badge status-badge order-status-${order.status}">${order.status}</span>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Table:</strong> ${order.table_number || 'N/A'}
                        </div>
                        <div class="col-md-6">
                            <strong>Customer:</strong> ${order.customer_name || 'Walk-in'}
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Staff:</strong> ${order.staff_name || 'N/A'}
                        </div>
                        <div class="col-md-6">
                            <strong>Date & Time:</strong> ${formatDateTime(order.order_date)}
                        </div>
                    </div>
                    <h6>Order Items:</h6>
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Item</th>
                                <th>Quantity</th>
                                <th>Price</th>
                                <th>Subtotal</th>
                                <th>Notes</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${itemsHtml}
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="3">Total Amount:</th>
                                <th colspan="2">${formatCurrency(order.total_amount)}</th>
                            </tr>
                        </tfoot>
                    </table>
                `;
                
                // Create a modal to display order details
                const modalHtml = `
                    <div class="modal fade" id="orderDetailsModal" tabindex="-1" aria-labelledby="orderDetailsModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="orderDetailsModalLabel">Order Details</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    ${orderDetailsHtml}
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
                
                // Remove existing modal if it exists
                const existingModal = document.getElementById('orderDetailsModal');
                if (existingModal) {
                    existingModal.remove();
                }
                
                // Add new modal to the body
                document.body.insertAdjacentHTML('beforeend', modalHtml);
                
                // Show the modal
                const modal = new bootstrap.Modal(document.getElementById('orderDetailsModal'));
                modal.show();
                
                // Remove modal from DOM after it's hidden
                document.getElementById('orderDetailsModal').addEventListener('hidden.bs.modal', function() {
                    this.remove();
                });
            }
        }
        
        // Update order status
        function updateOrderStatus(orderId, currentStatus) {
            document.getElementById('update-order-id').value = orderId;
            document.getElementById('update-order-status').value = currentStatus;
            
            const modal = new bootstrap.Modal(document.getElementById('updateOrderStatusModal'));
            modal.show();
        }
        
        // Update table status
        function updateTableStatus(tableId, currentStatus) {
            document.getElementById('update-table-id').value = tableId;
            document.getElementById('update-table-status').value = currentStatus;
            
            const modal = new bootstrap.Modal(document.getElementById('updateTableStatusModal'));
            modal.show();
        }
        
        // Update reservation status
        function updateReservationStatus(reservationId, currentStatus) {
            document.getElementById('update-reservation-id').value = reservationId;
            document.getElementById('update-reservation-status').value = currentStatus;
            
            const modal = new bootstrap.Modal(document.getElementById('updateReservationStatusModal'));
            modal.show();
        }
        
        // Add inventory transaction
        function addInventoryTransaction(itemId, itemName, itemQuantity, itemUnit) {
            document.getElementById('transaction-inventory-id').value = itemId;
            document.getElementById('transaction-quantity').value = '';
            document.getElementById('transaction-reference').value = '';
            document.getElementById('transaction-notes').value = '';
            
            // Update modal title
            document.getElementById('inventoryTransactionModalLabel').textContent = `Inventory Transaction - ${itemName} (Current: ${itemQuantity} ${itemUnit})`;
            
            const modal = new bootstrap.Modal(document.getElementById('inventoryTransactionModal'));
            modal.show();
        }
        
        // Edit menu item
        async function editMenuItem(itemId) {
            const item = await fetchData(`menu/${itemId}`);
            
            if (item) {
                document.getElementById('menuModalLabel').textContent = 'Edit Menu Item';
                document.getElementById('menu-name').value = item.name;
                document.getElementById('menu-description').value = item.description || '';
                document.getElementById('menu-price').value = item.price;
                document.getElementById('menu-category').value = item.category_id || '';
                document.getElementById('menu-image').value = item.image || '';
                document.getElementById('menu-available').checked = item.is_available;
                
                // Store the item ID for updating
                document.getElementById('menu-form').setAttribute('data-item-id', itemId);
                
                const modal = new bootstrap.Modal(document.getElementById('menuModal'));
                modal.show();
            }
        }
        
        // Edit inventory item
        async function editInventoryItem(itemId) {
            const item = await fetchData(`inventory/${itemId}`);
            
            if (item) {
                document.getElementById('inventoryModalLabel').textContent = 'Edit Inventory Item';
                document.getElementById('inventory-name').value = item.name;
                document.getElementById('inventory-description').value = item.description || '';
                document.getElementById('inventory-quantity').value = item.quantity;
                document.getElementById('inventory-unit').value = item.unit;
                document.getElementById('inventory-minimum-stock').value = item.minimum_stock;
                document.getElementById('inventory-unit-cost').value = item.unit_cost;
                
                // Store the item ID for updating
                document.getElementById('inventory-form').setAttribute('data-item-id', itemId);
                
                const modal = new bootstrap.Modal(document.getElementById('inventoryModal'));
                modal.show();
            }
        }
        
        // Edit customer
        async function editCustomer(customerId) {
            const customer = await fetchData(`customers/${customerId}`);
            
            if (customer) {
                document.getElementById('customerModalLabel').textContent = 'Edit Customer';
                document.getElementById('customer-name').value = customer.name;
                document.getElementById('customer-email').value = customer.email || '';
                document.getElementById('customer-phone').value = customer.phone || '';
                
                // Store the customer ID for updating
                document.getElementById('customer-form').setAttribute('data-customer-id', customerId);
                
                const modal = new bootstrap.Modal(document.getElementById('customerModal'));
                modal.show();
            }
        }
        
        // Delete table
        async function deleteTable(tableId) {
            const result = await sendData(`tables/${tableId}`, 'DELETE');
            
            if (result) {
                showToast('Table deleted successfully');
                loadTablesData();
            }
        }
        
        // Delete reservation
        async function deleteReservation(reservationId) {
            const result = await sendData(`reservations/${reservationId}`, 'DELETE');
            
            if (result) {
                showToast('Reservation deleted successfully');
                loadReservationsData();
            }
        }
        
        // Delete menu item
        async function deleteMenuItem(itemId) {
            const result = await sendData(`menu/${itemId}`, 'DELETE');
            
            if (result) {
                showToast('Menu item deleted successfully');
                loadMenuData();
            }
        }
        
        // Delete inventory item
        async function deleteInventoryItem(itemId) {
            const result = await sendData(`inventory/${itemId}`, 'DELETE');
            
            if (result) {
                showToast('Inventory item deleted successfully');
                loadInventoryData();
            }
        }
        
        // Delete customer
        async function deleteCustomer(customerId) {
            const result = await sendData(`customers/${customerId}`, 'DELETE');
            
            if (result) {
                showToast('Customer deleted successfully');
                loadCustomersData();
            }
        }
        
        // Initialize the application
        document.addEventListener('DOMContentLoaded', function() {
            // Load initial data
            loadDashboardData();
            
            // Set today's date as default for date filters
            const today = new Date().toISOString().split('T')[0];
            document.getElementById('order-date-filter').value = today;
            document.getElementById('reservation-date-filter').value = today;
            
            // Navigation
            document.querySelectorAll('.sidebar .nav-link').forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    // Remove active class from all links
                    document.querySelectorAll('.sidebar .nav-link').forEach(l => l.classList.remove('active'));
                    
                    // Add active class to clicked link
                    this.classList.add('active');
                    
                    // Hide all content sections
                    document.querySelectorAll('[id$="-content"]').forEach(section => {
                        section.style.display = 'none';
                    });
                    
                    // Show selected content section
                    const page = this.getAttribute('data-page');
                    document.getElementById(`${page}-content`).style.display = 'block';
                    
                    // Update page title
                    document.getElementById('page-title').textContent = this.textContent.trim();
                    
                    // Load page-specific data
                    currentPage = page;
                    
                    switch (page) {
                        case 'dashboard':
                            loadDashboardData();
                            break;
                        case 'orders':
                            loadOrdersData();
                            break;
                        case 'tables':
                            loadTablesData();
                            break;
                        case 'reservations':
                            loadReservationsData();
                            break;
                        case 'menu':
                            loadMenuData();
                            break;
                        case 'inventory':
                            loadInventoryData();
                            break;
                        case 'customers':
                            loadCustomersData();
                            break;
                        case 'reports':
                            // Load default sales report
                            loadReportsData('sales');
                            break;
                    }
                });
            });
            
            // Order form submission
            document.getElementById('save-order').addEventListener('click', async function() {
                const tableId = document.getElementById('order-table').value;
                const customerId = document.getElementById('order-customer').value || null;
                const notes = document.getElementById('order-notes').value;
                
                if (!tableId) {
                    showToast('Please select a table', 'error');
                    return;
                }
                
                // Get order items
                const orderItems = [];
                const itemRows = document.querySelectorAll('#order-items .order-item-row');
                
                for (const row of itemRows) {
                    const menuItemId = row.querySelector('.menu-item-select').value;
                    const quantity = row.querySelector('.item-quantity').value;
                    
                    if (!menuItemId || !quantity) {
                        showToast('Please complete all item fields', 'error');
                        return;
                    }
                    
                    const menuItem = menuItems.find(item => item.id == menuItemId);
                    
                    orderItems.push({
                        menu_item_id: menuItemId,
                        quantity: quantity,
                        price: menuItem.price,
                        notes: ''
                    });
                }
                
                if (orderItems.length === 0) {
                    showToast('Please add at least one item to the order', 'error');
                    return;
                }
                
                const orderData = {
                    table_id: tableId,
                    customer_id: customerId,
                    items: orderItems,
                    notes: notes
                };
                
                const result = await sendData('orders', 'POST', orderData);
                
                if (result) {
                    showToast('Order created successfully');
                    bootstrap.Modal.getInstance(document.getElementById('orderModal')).hide();
                    document.getElementById('order-form').reset();
                    document.getElementById('order-total').value = '';
                    
                    // Reset order items to one empty row
                    const orderItemsContainer = document.getElementById('order-items');
                    orderItemsContainer.innerHTML = `
                        <div class="row mb-2 order-item-row">
                            <div class="col-md-5">
                                <select class="form-select menu-item-select" required>
                                    <option value="">Select Item</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <input type="number" class="form-control item-quantity" min="1" value="1" required>
                            </div>
                            <div class="col-md-3">
                                <input type="text" class="form-control item-price" readonly>
                            </div>
                            <div class="col-md-2">
                                <button type="button" class="btn btn-danger btn-sm remove-item">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                    `;
                    
                    // Re-populate menu item selects
                    menuItems.forEach(item => {
                        if (item.is_available) {
                            const option = document.createElement('option');
                            option.value = item.id;
                            option.textContent = `${item.name} - ${formatCurrency(item.price)}`;
                            option.setAttribute('data-price', item.price);
                            document.querySelectorAll('.menu-item-select').forEach(select => {
                                select.appendChild(option.cloneNode(true));
                            });
                        }
                    });
                    
                    // Reload orders data if on orders page
                    if (currentPage === 'orders') {
                        loadOrdersData();
                    } else {
                        loadDashboardData();
                    }
                }
            });
            
            // Table form submission
            document.getElementById('save-table').addEventListener('click', async function() {
                const tableNumber = document.getElementById('table-number').value;
                const capacity = document.getElementById('table-capacity').value;
                const location = document.getElementById('table-location').value;
                
                if (!tableNumber || !capacity) {
                    showToast('Please fill in all required fields', 'error');
                    return;
                }
                
                const tableData = {
                    table_number: tableNumber,
                    capacity: capacity,
                    location: location
                };
                
                const result = await sendData('tables', 'POST', tableData);
                
                if (result) {
                    showToast('Table added successfully');
                    bootstrap.Modal.getInstance(document.getElementById('tableModal')).hide();
                    document.getElementById('table-form').reset();
                    
                    // Reload tables data
                    loadTablesData();
                }
            });
            
            // Reservation form submission
            document.getElementById('save-reservation').addEventListener('click', async function() {
                const customerName = document.getElementById('reservation-customer-name').value;
                const customerEmail = document.getElementById('reservation-customer-email').value;
                const customerPhone = document.getElementById('reservation-customer-phone').value;
                const date = document.getElementById('reservation-date').value;
                const time = document.getElementById('reservation-time').value;
                const tableId = document.getElementById('reservation-table').value;
                const partySize = document.getElementById('reservation-party-size').value;
                const specialRequests = document.getElementById('reservation-special-requests').value;
                
                if (!customerName || !date || !time || !tableId || !partySize) {
                    showToast('Please fill in all required fields', 'error');
                    return;
                }
                
                const reservationData = {
                    customer_name: customerName,
                    customer_email: customerEmail,
                    customer_phone: customerPhone,
                    reservation_date: date,
                    reservation_time: time,
                    table_id: tableId,
                    party_size: partySize,
                    special_requests: specialRequests
                };
                
                const result = await sendData('reservations', 'POST', reservationData);
                
                if (result) {
                    showToast('Reservation created successfully');
                    bootstrap.Modal.getInstance(document.getElementById('reservationModal')).hide();
                    document.getElementById('reservation-form').reset();
                    
                    // Reload reservations data
                    loadReservationsData();
                }
            });
            
            // Menu form submission
            document.getElementById('save-menu').addEventListener('click', async function() {
                const name = document.getElementById('menu-name').value;
                const description = document.getElementById('menu-description').value;
                const price = document.getElementById('menu-price').value;
                const categoryId = document.getElementById('menu-category').value;
                const image = document.getElementById('menu-image').value;
                const isAvailable = document.getElementById('menu-available').checked;
                
                if (!name || !price || !categoryId) {
                    showToast('Please fill in all required fields', 'error');
                    return;
                }
                
                const menuData = {
                    name: name,
                    description: description,
                    price: price,
                    category_id: categoryId,
                    image: image,
                    is_available: isAvailable
                };
                
                const form = document.getElementById('menu-form');
                const itemId = form.getAttribute('data-item-id');
                
                let result;
                if (itemId) {
                    // Update existing item
                    result = await sendData(`menu/${itemId}`, 'PUT', menuData);
                    form.removeAttribute('data-item-id');
                } else {
                    // Add new item
                    result = await sendData('menu', 'POST', menuData);
                }
                
                if (result) {
                    showToast(itemId ? 'Menu item updated successfully' : 'Menu item added successfully');
                    bootstrap.Modal.getInstance(document.getElementById('menuModal')).hide();
                    document.getElementById('menu-form').reset();
                    document.getElementById('menuModalLabel').textContent = 'Add Menu Item';
                    
                    // Reload menu data
                    loadMenuData();
                }
            });
            
            // Inventory form submission
            document.getElementById('save-inventory').addEventListener('click', async function() {
                const name = document.getElementById('inventory-name').value;
                const description = document.getElementById('inventory-description').value;
                const quantity = document.getElementById('inventory-quantity').value;
                const unit = document.getElementById('inventory-unit').value;
                const minimumStock = document.getElementById('inventory-minimum-stock').value;
                const unitCost = document.getElementById('inventory-unit-cost').value;
                
                if (!name || !quantity || !unit || !minimumStock || !unitCost) {
                    showToast('Please fill in all required fields', 'error');
                    return;
                }
                
                const inventoryData = {
                    name: name,
                    description: description,
                    quantity: quantity,
                    unit: unit,
                    minimum_stock: minimumStock,
                    unit_cost: unitCost
                };
                
                const form = document.getElementById('inventory-form');
                const itemId = form.getAttribute('data-item-id');
                
                let result;
                if (itemId) {
                    // Update existing item
                    result = await sendData(`inventory/${itemId}`, 'PUT', inventoryData);
                    form.removeAttribute('data-item-id');
                } else {
                    // Add new item
                    result = await sendData('inventory', 'POST', inventoryData);
                }
                
                if (result) {
                    showToast(itemId ? 'Inventory item updated successfully' : 'Inventory item added successfully');
                    bootstrap.Modal.getInstance(document.getElementById('inventoryModal')).hide();
                    document.getElementById('inventory-form').reset();
                    document.getElementById('inventoryModalLabel').textContent = 'Add Inventory Item';
                    
                    // Reload inventory data
                    loadInventoryData();
                }
            });
            
            // Customer form submission
            document.getElementById('save-customer').addEventListener('click', async function() {
                const name = document.getElementById('customer-name').value;
                const email = document.getElementById('customer-email').value;
                const phone = document.getElementById('customer-phone').value;
                
                if (!name) {
                    showToast('Please fill in the name field', 'error');
                    return;
                }
                
                const customerData = {
                    name: name,
                    email: email,
                    phone: phone
                };
                
                const form = document.getElementById('customer-form');
                const customerId = form.getAttribute('data-customer-id');
                
                let result;
                if (customerId) {
                    // Update existing customer
                    result = await sendData(`customers/${customerId}`, 'PUT', customerData);
                    form.removeAttribute('data-customer-id');
                } else {
                    // Add new customer
                    result = await sendData('customers', 'POST', customerData);
                }
                
                if (result) {
                    showToast(customerId ? 'Customer updated successfully' : 'Customer added successfully');
                    bootstrap.Modal.getInstance(document.getElementById('customerModal')).hide();
                    document.getElementById('customer-form').reset();
                    document.getElementById('customerModalLabel').textContent = 'Add Customer';
                    
                    // Reload customers data
                    loadCustomersData();
                }
            });
            
            // Update order status form submission
            document.getElementById('update-order-status-btn').addEventListener('click', async function() {
                const orderId = document.getElementById('update-order-id').value;
                const status = document.getElementById('update-order-status').value;
                
                const result = await sendData(`orders/${orderId}`, 'PUT', { status: status });
                
                if (result) {
                    showToast('Order status updated successfully');
                    bootstrap.Modal.getInstance(document.getElementById('updateOrderStatusModal')).hide();
                    
                    // Reload orders data
                    if (currentPage === 'orders') {
                        loadOrdersData();
                    } else {
                        loadDashboardData();
                    }
                }
            });
            
            // Update table status form submission
            document.getElementById('update-table-status-btn').addEventListener('click', async function() {
                const tableId = document.getElementById('update-table-id').value;
                const status = document.getElementById('update-table-status').value;
                
                const table = tables.find(t => t.id == tableId);
                if (!table) return;
                
                const result = await sendData(`tables/${tableId}`, 'PUT', {
                    table_number: table.table_number,
                    capacity: table.capacity,
                    status: status,
                    location: table.location
                });
                
                if (result) {
                    showToast('Table status updated successfully');
                    bootstrap.Modal.getInstance(document.getElementById('updateTableStatusModal')).hide();
                    
                    // Reload tables data
                    loadTablesData();
                }
            });
            
            // Update reservation status form submission
            document.getElementById('update-reservation-status-btn').addEventListener('click', async function() {
                const reservationId = document.getElementById('update-reservation-id').value;
                const status = document.getElementById('update-reservation-status').value;
                
                // Get reservation details
                const reservation = await fetchData(`reservations/${reservationId}`);
                if (!reservation) return;
                
                const result = await sendData(`reservations/${reservationId}`, 'PUT', {
                    table_id: reservation.table_id,
                    reservation_date: reservation.reservation_date,
                    reservation_time: reservation.reservation_time,
                    party_size: reservation.party_size,
                    status: status,
                    special_requests: reservation.special_requests
                });
                
                if (result) {
                    showToast('Reservation status updated successfully');
                    bootstrap.Modal.getInstance(document.getElementById('updateReservationStatusModal')).hide();
                    
                    // Reload reservations data
                    loadReservationsData();
                }
            });
            
            // Inventory transaction form submission
            document.getElementById('save-transaction').addEventListener('click', async function() {
                const inventoryId = document.getElementById('transaction-inventory-id').value;
                const transactionType = document.getElementById('transaction-type').value;
                const quantity = document.getElementById('transaction-quantity').value;
                const reference = document.getElementById('transaction-reference').value;
                const notes = document.getElementById('transaction-notes').value;
                
                if (!quantity) {
                    showToast('Please enter a quantity', 'error');
                    return;
                }
                
                // Get current inventory item
                const item = await fetchData(`inventory/${inventoryId}`);
                if (!item) return;
                
                // Calculate new quantity
                let newQuantity;
                if (transactionType === 'in') {
                    newQuantity = parseFloat(item.quantity) + parseFloat(quantity);
                } else {
                    newQuantity = parseFloat(item.quantity) - parseFloat(quantity);
                    
                    if (newQuantity < 0) {
                        showToast('Insufficient stock for this transaction', 'error');
                        return;
                    }
                }
                
                // Update inventory item
                const updateResult = await sendData(`inventory/${inventoryId}`, 'PUT', {
                    name: item.name,
                    description: item.description,
                    quantity: newQuantity,
                    unit: item.unit,
                    minimum_stock: item.minimum_stock,
                    unit_cost: item.unit_cost
                });
                
                if (updateResult) {
                    // Add transaction record
                    const transactionData = {
                        inventory_id: inventoryId,
                        transaction_type: transactionType,
                        quantity: quantity,
                        reference: reference,
                        notes: notes
                    };
                    
                    // This would require a separate API endpoint for transactions
                    // For now, we'll just show success and reload the data
                    
                    showToast('Transaction completed successfully');
                    bootstrap.Modal.getInstance(document.getElementById('inventoryTransactionModal')).hide();
                    
                    // Reload inventory data
                    loadInventoryData();
                }
            });
            
            // Add order item button
            document.getElementById('add-order-item').addEventListener('click', function() {
                const orderItemsContainer = document.getElementById('order-items');
                const newItemRow = document.createElement('div');
                newItemRow.className = 'row mb-2 order-item-row';
                newItemRow.innerHTML = `
                    <div class="col-md-5">
                        <select class="form-select menu-item-select" required>
                            <option value="">Select Item</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <input type="number" class="form-control item-quantity" min="1" value="1" required>
                    </div>
                    <div class="col-md-3">
                        <input type="text" class="form-control item-price" readonly>
                    </div>
                    <div class="col-md-2">
                        <button type="button" class="btn btn-danger btn-sm remove-item">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                `;
                
                orderItemsContainer.appendChild(newItemRow);
                
                // Populate menu item select
                const select = newItemRow.querySelector('.menu-item-select');
                menuItems.forEach(item => {
                    if (item.is_available) {
                        const option = document.createElement('option');
                        option.value = item.id;
                        option.textContent = `${item.name} - ${formatCurrency(item.price)}`;
                        option.setAttribute('data-price', item.price);
                        select.appendChild(option);
                    }
                });
                
                // Add event listeners
                select.addEventListener('change', updateOrderTotal);
                newItemRow.querySelector('.item-quantity').addEventListener('input', updateOrderTotal);
                newItemRow.querySelector('.remove-item').addEventListener('click', function() {
                    if (orderItemsContainer.querySelectorAll('.order-item-row').length > 1) {
                        newItemRow.remove();
                        updateOrderTotal();
                    } else {
                        showToast('You must have at least one item', 'error');
                    }
                });
            });
            
            // Update order total when item or quantity changes
            function updateOrderTotal() {
                let total = 0;
                
                document.querySelectorAll('#order-items .order-item-row').forEach(row => {
                    const select = row.querySelector('.menu-item-select');
                    const quantity = row.querySelector('.item-quantity').value;
                    const priceInput = row.querySelector('.item-price');
                    
                    if (select.value && quantity) {
                        const price = parseFloat(select.options[select.selectedIndex].getAttribute('data-price'));
                        priceInput.value = formatCurrency(price);
                        total += price * parseInt(quantity);
                    } else {
                        priceInput.value = '';
                    }
                });
                
                document.getElementById('order-total').value = formatCurrency(total);
            }
            
            // Add event listeners for initial order item row
            document.querySelectorAll('.menu-item-select').forEach(select => {
                select.addEventListener('change', updateOrderTotal);
            });
            
            document.querySelectorAll('.item-quantity').forEach(input => {
                input.addEventListener('input', updateOrderTotal);
            });
            
            document.querySelectorAll('.remove-item').forEach(btn => {
                btn.addEventListener('click', function() {
                    const row = this.closest('.order-item-row');
                    const container = document.getElementById('order-items');
                    
                    if (container.querySelectorAll('.order-item-row').length > 1) {
                        row.remove();
                        updateOrderTotal();
                    } else {
                        showToast('You must have at least one item', 'error');
                    }
                });
            });
            
            // Filter event listeners
            document.getElementById('order-status-filter').addEventListener('change', loadOrdersData);
            document.getElementById('order-date-filter').addEventListener('change', loadOrdersData);
            document.getElementById('order-search').addEventListener('input', function() {
                // This would implement client-side filtering
                // For simplicity, we're not implementing this in the example
            });
            
            document.getElementById('table-status-filter').addEventListener('change', function() {
                const status = this.value;
                const filteredTables = status ? tables.filter(table => table.status === status) : tables;
                
                // Re-display filtered tables
                const tablesTbody = document.getElementById('tables-tbody');
                tablesTbody.innerHTML = '';
                
                filteredTables.forEach(table => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${table.table_number}</td>
                        <td>${table.capacity}</td>
                        <td><span class="badge status-badge table-status-${table.status}">${table.status}</span></td>
                        <td>${table.location || 'N/A'}</td>
                        <td class="table-actions">
                            <button class="btn btn-sm btn-outline-secondary update-table-status" data-id="${table.id}" data-status="${table.status}">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-outline-danger delete-table" data-id="${table.id}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    `;
                    tablesTbody.appendChild(row);
                });
                
                // Re-add event listeners
                document.querySelectorAll('.update-table-status').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const tableId = this.getAttribute('data-id');
                        const currentStatus = this.getAttribute('data-status');
                        updateTableStatus(tableId, currentStatus);
                    });
                });
                
                document.querySelectorAll('.delete-table').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const tableId = this.getAttribute('data-id');
                        if (confirm('Are you sure you want to delete this table?')) {
                            deleteTable(tableId);
                        }
                    });
                });
            });
            
            document.getElementById('table-location-filter').addEventListener('change', function() {
                const location = this.value;
                const filteredTables = location ? tables.filter(table => table.location === location) : tables;
                
                // Re-display filtered tables
                const tablesTbody = document.getElementById('tables-tbody');
                tablesTbody.innerHTML = '';
                
                filteredTables.forEach(table => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${table.table_number}</td>
                        <td>${table.capacity}</td>
                        <td><span class="badge status-badge table-status-${table.status}">${table.status}</span></td>
                        <td>${table.location || 'N/A'}</td>
                        <td class="table-actions">
                            <button class="btn btn-sm btn-outline-secondary update-table-status" data-id="${table.id}" data-status="${table.status}">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-outline-danger delete-table" data-id="${table.id}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    `;
                    tablesTbody.appendChild(row);
                });
                
                // Re-add event listeners
                document.querySelectorAll('.update-table-status').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const tableId = this.getAttribute('data-id');
                        const currentStatus = this.getAttribute('data-status');
                        updateTableStatus(tableId, currentStatus);
                    });
                });
                
                document.querySelectorAll('.delete-table').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const tableId = this.getAttribute('data-id');
                        if (confirm('Are you sure you want to delete this table?')) {
                            deleteTable(tableId);
                        }
                    });
                });
            });
            
            document.getElementById('reservation-status-filter').addEventListener('change', loadReservationsData);
            document.getElementById('reservation-date-filter').addEventListener('change', loadReservationsData);
            document.getElementById('refresh-reservations').addEventListener('click', loadReservationsData);
            
            document.getElementById('menu-category-filter').addEventListener('change', function() {
                const categoryId = this.value;
                const filteredItems = categoryId ? menuItems.filter(item => item.category_id == categoryId) : menuItems;
                displayMenuItems(filteredItems);
            });
            
            document.getElementById('menu-availability-filter').addEventListener('change', function() {
                const isAvailable = this.value;
                let filteredItems;
                
                if (isAvailable === '') {
                    filteredItems = menuItems;
                } else {
                    const available = isAvailable === '1';
                    filteredItems = menuItems.filter(item => item.is_available === available);
                }
                
                displayMenuItems(filteredItems);
            });
            
            document.getElementById('inventory-stock-filter').addEventListener('change', function() {
                const stockStatus = this.value;
                const inventoryItems = Array.from(document.querySelectorAll('#inventory-tbody tr'));
                
                inventoryItems.forEach(row => {
                    const quantityCell = row.cells[2];
                    
                    if (stockStatus === '') {
                        row.style.display = '';
                    } else if (stockStatus === 'low' && quantityCell.classList.contains('inventory-low')) {
                        row.style.display = '';
                    } else if (stockStatus === 'ok' && quantityCell.classList.contains('inventory-ok')) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            });
            
            // Report generation buttons
            document.getElementById('generate-sales-report').addEventListener('click', function() {
                loadReportsData('sales');
            });
            
            document.getElementById('generate-inventory-report').addEventListener('click', function() {
                loadReportsData('inventory');
            });
            
            document.getElementById('generate-reservations-report').addEventListener('click', function() {
                loadReportsData('reservations');
            });
            
            // Load tables for order and reservation modals
            async function loadTablesForModals() {
                const tablesData = await fetchData('tables');
                
                if (tablesData) {
                    // Populate order table dropdown
                    const orderTable = document.getElementById('order-table');
                    orderTable.innerHTML = '<option value="">Select Table</option>';
                    
                    tablesData.filter(table => table.status === 'available').forEach(table => {
                        const option = document.createElement('option');
                        option.value = table.id;
                        option.textContent = `Table ${table.table_number} (Capacity: ${table.capacity})`;
                        orderTable.appendChild(option);
                    });
                    
                    // Populate reservation table dropdown
                    const reservationTable = document.getElementById('reservation-table');
                    reservationTable.innerHTML = '<option value="">Select Table</option>';
                    
                    tablesData.forEach(table => {
                        const option = document.createElement('option');
                        option.value = table.id;
                        option.textContent = `Table ${table.table_number} (Capacity: ${table.capacity})`;
                        reservationTable.appendChild(option);
                    });
                }
            }
            
            // Load tables when modals are shown
            document.getElementById('orderModal').addEventListener('show.bs.modal', loadTablesForModals);
            document.getElementById('reservationModal').addEventListener('show.bs.modal', loadTablesForModals);
            
            // Set today's date as default for reservation date
            document.getElementById('reservation-date').value = today;
        });
    </script>
</body>
</html>